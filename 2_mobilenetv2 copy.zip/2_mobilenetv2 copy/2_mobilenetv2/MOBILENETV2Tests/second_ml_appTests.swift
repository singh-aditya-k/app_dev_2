//
//  second_ml_appTests.swift
//  second_ml_appTests
//
//  Created by Singh, Aditya Kumar on 4/20/25.
//

import Testing
@testable import second_ml_app

struct second_ml_appTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
