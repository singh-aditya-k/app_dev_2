import SwiftUI

@main
struct second_ml_appApp: App {
    var body: some Scene {
        WindowGroup {
            SplashView()
        }
    }
}
