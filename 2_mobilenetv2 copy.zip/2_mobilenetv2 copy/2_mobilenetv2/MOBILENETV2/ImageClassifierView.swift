import SwiftUI

struct ImageClassifierView: View {
    @State private var image: UIImage?
    @State private var result: String = "Pick an image to classify"
    @State private var confidence: Float = 0.0
    @State private var emoji: String = ""
    @State private var showResults = false
    @State private var showPicker = false

    var body: some View {
        VStack(spacing: 25) {
            // ℹ️ Instructions
            if !showResults {
                Text("Select an image and I'll try to identify what’s in it using Apple’s MobileNetV2 model.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }

            // 📸 Selected image
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 300)
                    .cornerRadius(12)
                    .shadow(radius: 10)
                    .padding()
                    .transition(.opacity)
            }

            // ✅ Results shown
            if showResults {
                VStack(spacing: 16) {
                    Text(emoji)
                        .font(.system(size: 64))

                    VStack(spacing: 4) {
                        Text("Prediction")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .bold()

                        Text(resultLabel)
                            .font(.title2)
                            .fontWeight(.semibold)

                        Text(String(format: "Confidence: %.1f%%", confidence * 100))
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }

                    // Confidence bar with slider styling
                    VStack(spacing: 10) {
                        ZStack(alignment: .leading) {
                            Capsule()
                                .fill(Color.gray.opacity(0.2))
                                .frame(height: 24)

                            Capsule()
                                .fill(confidenceColor)
                                .frame(width: barWidth, height: 24)
                                .animation(.easeInOut, value: confidence)

                            Circle()
                                .fill(Color.white)
                                .frame(width: 24, height: 24)
                                .overlay(Circle().stroke(Color.black.opacity(0.1), lineWidth: 1))
                                .offset(x: barWidth - 12)
                                .shadow(radius: 2)
                                .animation(.easeInOut, value: confidence)
                        }
                    }
                    .padding(.horizontal)
                }
                .transition(.opacity)
            } else {
                Text(result)
                    .font(.headline)
                    .padding()
            }

            // Image Picker button
            Button("Pick Image") {
                showPicker = true
                showResults = false
            }
            .padding()
            .buttonStyle(.borderedProminent)
        }
        .animation(.easeInOut, value: showResults)
        .sheet(isPresented: $showPicker) {
            PhotoPicker(
                image: $image,
                result: $result,
                confidence: $confidence,
                emoji: $emoji,
                showResults: $showResults
            )
        }
    }

    private var confidenceColor: Color {
        switch confidence {
        case 0.8...1.0:
            return .green
        case 0.5..<0.8:
            return .yellow
        default:
            return .red
        }
    }

    private var barWidth: CGFloat {
        let screenWidth = UIScreen.main.bounds.width - 40
        return CGFloat(confidence) * screenWidth
    }

    private var resultLabel: String {
        if result.lowercased().hasPrefix("prediction:") {
            return result.replacingOccurrences(of: "Prediction: ", with: "")
        }
        return result
    }
}
