//
//  PhotoPicker.swift
//  second_ml_app
//
//  Created by Singh, Aditya Kumar on 4/20/25.
//


import SwiftUI
import PhotosUI
import Vision
import CoreML

struct PhotoPicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Binding var result: String
    @Binding var confidence: Float
    @Binding var emoji: String
    @Binding var showResults: Bool

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration()
        config.filter = .images
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: PhotoPicker

        init(_ parent: PhotoPicker) {
            self.parent = parent
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)

            guard let provider = results.first?.itemProvider,
                  provider.canLoadObject(ofClass: UIImage.self) else {
                return
            }

            provider.loadObject(ofClass: UIImage.self) { object, _ in
                DispatchQueue.main.async {
                    if let uiImage = object as? UIImage {
                        self.parent.image = uiImage
                        self.classifyImage(uiImage)
                    }
                }
            }
        }

        func classifyImage(_ image: UIImage) {
            guard let model = try? VNCoreMLModel(for: MobileNetV2().model) else {
                parent.result = "Failed to load model"
                return
            }

            let request = VNCoreMLRequest(model: model) { request, _ in
                guard let result = request.results?.first as? VNClassificationObservation else {
                    DispatchQueue.main.async {
                        self.parent.result = "No classification found"
                        self.parent.showResults = true
                    }
                    return
                }

                let label = result.identifier
                let conf = result.confidence
                let emoji = self.emojiFor(label: label)

                DispatchQueue.main.async {
                    self.parent.result = "Prediction: \(label.capitalized)"
                    self.parent.confidence = conf
                    self.parent.emoji = emoji
                    self.parent.showResults = true
                }
            }

            guard let ciImage = CIImage(image: image) else {
                parent.result = "Invalid image"
                return
            }

            let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
            try? handler.perform([request])
        }

        func emojiFor(label: String) -> String {
            let lookup: [String: String] = [
                "lion": "🦁",
                "dog": "🐶",
                "cat": "🐱",
                "elephant": "🐘",
                "zebra": "🦓",
                "tiger": "🐯",
                "cheetah": "🐆",
                "horse": "🐴",
                "airplane": "✈️",
                "car": "🚗",
                "bicycle": "🚲",
                "person": "🧍",
                "banana": "🍌",
                "apple": "🍎",
                "pizza": "🍕",
                "cake": "🎂",
                "bird": "🐦"
            ]

            for (keyword, emoji) in lookup {
                if label.lowercased().contains(keyword) {
                    return emoji
                }
            }

            return "🤖"
        }
    }
}
