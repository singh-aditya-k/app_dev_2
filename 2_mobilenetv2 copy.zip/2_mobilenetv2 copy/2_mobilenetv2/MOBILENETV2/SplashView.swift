//
//  SplashView.swift
//  second_ml_app
//
//  Created by Singh, Aditya Kumar on 4/20/25.
//


import SwiftUI

struct SplashView: View {
    @State private var isActive = false

    var body: some View {
        if isActive {
            ImageClassifierView()
        } else {
            VStack(spacing: 16) {
                Text("🧠")
                    .font(.system(size: 80))
                    .scaleEffect(isActive ? 1.2 : 1.0)
                    .animation(.easeInOut(duration: 0.8), value: isActive)

                Text("CoreML Classifier")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.white)
            .ignoresSafeArea()
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    withAnimation {
                        isActive = true
                    }
                }
            }
        }
    }
}
