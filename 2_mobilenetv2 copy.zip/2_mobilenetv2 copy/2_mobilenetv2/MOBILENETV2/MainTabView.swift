import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            ImageClassifierView()
                .tabItem {
                    Label("Classify", systemImage: "photo")
                }
        }
    }
}
