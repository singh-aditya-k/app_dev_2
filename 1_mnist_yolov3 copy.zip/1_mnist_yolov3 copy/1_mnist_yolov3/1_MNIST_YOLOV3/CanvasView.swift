import SwiftUI
import CoreML
import UIKit
import PhotosUI // ← for image picker


struct CanvasView: UIViewRepresentable {
    @Binding var drawingView: DrawingView

    func makeUIView(context: Context) -> DrawingView {
        return drawingView
    }

    func updateUIView(_ uiView: DrawingView, context: Context) {}
}
