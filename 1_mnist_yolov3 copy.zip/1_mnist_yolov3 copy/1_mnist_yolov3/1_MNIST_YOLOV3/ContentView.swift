import SwiftUI
import CoreML
import UIKit
import PhotosUI // ← for image picker


struct ContentView: View {
    var body: some View {
        TabView {
            // First tab
            DigitMultiplyView()
                .tabItem {
                    Label("Multiply", systemImage: "plus.slash.minus")
                }

            // Third tab
            ObjectDetectorView()
                .tabItem {
                    Label("Detect", systemImage: "viewfinder")
                }

        }
    }
}
