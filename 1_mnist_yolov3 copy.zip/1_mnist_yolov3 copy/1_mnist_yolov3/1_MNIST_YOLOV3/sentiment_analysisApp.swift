//
//  sentiment_analysisApp.swift
//  sentiment_analysis
//
//  Created by Singh, Aditya Kumar on 4/20/25.
//

import SwiftUI
import CoreML
import UIKit
import PhotosUI // ← for image picker

@main
struct sentiment_analysisApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
