//
//  SplashView.swift
//  sentiment_analysis
//
//  Created by Singh, Aditya Kumar on 4/20/25.
//


import SwiftUI

struct SplashView: View {
    @State private var isActive = false

    var body: some View {
        Group {
            if isActive {
                ContentView()
            } else {
                VStack(spacing: 20) {
                    Text("🧠 ML Playground")
                        .font(.largeTitle)
                        .bold()
                    Text("Made with CoreML + SwiftUI")
                        .font(.subheadline)
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.white)
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        isActive = true
                    }
                }
            }
        }
    }
}
