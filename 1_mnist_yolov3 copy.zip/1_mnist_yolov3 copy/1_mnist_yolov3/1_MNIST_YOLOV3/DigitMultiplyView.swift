import SwiftUI
import CoreML
import UIKit

struct DigitMultiplyView: View {
    @State private var canvas1 = DrawingView()
    @State private var canvas2 = DrawingView()
    @State private var canvas3 = DrawingView()
    @State private var canvas4 = DrawingView()

    @State private var prediction1 = "?"
    @State private var prediction2 = "?"
    @State private var prediction3 = "?"
    @State private var prediction4 = "?"

    @State private var confidence1: Double = 0
    @State private var confidence2: Double = 0
    @State private var confidence3: Double = 0
    @State private var confidence4: Double = 0

    @State private var resultText = ""

    var body: some View {
        VStack(spacing: 16) {
            Text("Multiply Digits")
                .font(.title)
                .bold()

            Text("✏️ Draw 4 digits in the boxes. The top two form one number, the bottom two form another. Tap 'Calculate' to multiply them.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .padding(.bottom)

            HStack(spacing: 16) {
                digitCanvas(canvas: $canvas1, prediction: prediction1, confidence: confidence1) { prediction1 = "?" }
                digitCanvas(canvas: $canvas2, prediction: prediction2, confidence: confidence2) { prediction2 = "?" }
            }

            HStack(spacing: 16) {
                digitCanvas(canvas: $canvas3, prediction: prediction3, confidence: confidence3) { prediction3 = "?" }
                digitCanvas(canvas: $canvas4, prediction: prediction4, confidence: confidence4) { prediction4 = "?" }
            }

            Button("Calculate") {
                let resultA = predictDigit(from: canvas1)
                prediction1 = resultA.digit
                confidence1 = resultA.confidence

                let resultB = predictDigit(from: canvas2)
                prediction2 = resultB.digit
                confidence2 = resultB.confidence

                let resultC = predictDigit(from: canvas3)
                prediction3 = resultC.digit
                confidence3 = resultC.confidence

                let resultD = predictDigit(from: canvas4)
                prediction4 = resultD.digit
                confidence4 = resultD.confidence

                if let top = Int(prediction1 + prediction2),
                   let bottom = Int(prediction3 + prediction4) {
                    resultText = "\(top) × \(bottom) = \(top * bottom)"
                } else {
                    resultText = "❗ Please draw all digits clearly"
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.blue)

            VStack(spacing: 8) {
                Text("Top: \(prediction1) \(prediction2)")
                Text("Bottom: \(prediction3) \(prediction4)")
                Text(resultText)
                    .font(.title)
                    .bold()
                    .foregroundColor(resultText.contains("=") ? .green : .red)
                    .padding(.top, 4)
            }

            Spacer()
        }
        .padding()
    }

    func digitCanvas(canvas: Binding<DrawingView>, prediction: String, confidence: Double, onClear: @escaping () -> Void) -> some View {
        VStack {
            CanvasView(drawingView: canvas)
                .frame(width: 150, height: 150)
                .border(Color.gray)

            Button("Clear") {
                canvas.wrappedValue.clear()
                onClear()
            }
            .buttonStyle(.borderedProminent)

            Text("Confidence: \(Int(confidence * 100))%")
            ProgressView(value: confidence)
                .progressViewStyle(LinearProgressViewStyle(tint: .green))
        }
    }

    func predictDigit(from canvas: DrawingView) -> (digit: String, confidence: Double) {
        guard let image = canvas.getImage().resize(to: CGSize(width: 28, height: 28)),
              let buffer = image.toRGBPixelBuffer() else {
            return ("?", 0)
        }

        guard let model = try? MNISTClassifier(configuration: MLModelConfiguration()),
              let output = try? model.prediction(image: buffer) else {
            return ("?", 0)
        }

        return (String(output.classLabel), 1.0) // fake 100% confidence
    }
}
