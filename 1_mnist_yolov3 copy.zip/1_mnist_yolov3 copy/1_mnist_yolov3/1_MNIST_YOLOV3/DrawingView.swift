import SwiftUI
import CoreML
import UIKit
import PhotosUI // ← for image picker


class DrawingView: UIView {
    private var path = UIBezierPath()
    private var previousPoint: CGPoint?

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .black
        path.lineWidth = 10
        isMultipleTouchEnabled = false
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: self) {
            previousPoint = point
            path.move(to: point)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let point = touches.first?.location(in: self),
              let previousPoint = previousPoint else { return }
        path.addLine(to: point)
        self.previousPoint = point
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        UIColor.white.setStroke()
        path.stroke()
    }

    func clear() {
        path = UIBezierPath()
        path.lineWidth = 10
        setNeedsDisplay()
    }

    func getImage() -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { ctx in
            layer.render(in: ctx.cgContext)
        }
    }
}
