//
//  ObjectDetectorView.swift
//  sentiment_analysis
//
//  Created by Singh, Aditya Kumar on 4/20/25.
//


import SwiftUI
import CoreML
import Vision
import UIKit

struct ObjectDetectorView: View {
    @State private var selectedImage: UIImage?
    @State private var showingImagePicker = false
    @State private var detectedObjects: [String] = []

    var body: some View {
        VStack(spacing: 16) {
            Text("Object Detector")
                .font(.title)
                .bold()

            Text("📸 Pick an image and YOLOv3 will detect and label objects it sees.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .padding(.bottom)

            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 250)
            } else {
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .frame(height: 250)
                    .overlay(Text("No image selected"))
            }

            Button("Pick Photo") {
                showingImagePicker = true
            }
            .buttonStyle(.borderedProminent)

            Button("Detect Objects") {
                detectObjects()
            }
            .buttonStyle(.borderedProminent)

            if !detectedObjects.isEmpty {
                Text("Detected Objects:")
                    .font(.headline)
                ForEach(detectedObjects, id: \.self) { object in
                    Text("• \(object)")
                }
            }

            Spacer()
        }
        .padding()
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(image: $selectedImage)
        }
    }

    func detectObjects() {
        guard let image = selectedImage,
              let cgImage = image.cgImage else {
            detectedObjects = ["❌ No image selected or invalid format."]
            return
        }

        detectedObjects = [] // reset

        guard let model = try? VNCoreMLModel(for: YOLOv3().model) else {
            detectedObjects = ["❌ Failed to load YOLOv3 model."]
            return
        }

        let request = VNCoreMLRequest(model: model) { request, error in
            if let results = request.results as? [VNRecognizedObjectObservation] {
                let labels = results.compactMap { observation in
                    observation.labels.first?.identifier
                }
                DispatchQueue.main.async {
                    self.detectedObjects = labels.isEmpty ? ["Nothing found"] : labels
                }
            } else {
                DispatchQueue.main.async {
                    self.detectedObjects = ["❌ Failed to recognize objects."]
                }
            }
        }

        let handler = VNImageRequestHandler(cgImage: cgImage)
        try? handler.perform([request])
    }
}
